
-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--
-- Creation: Oct 12, 2023 at 10:02 AM
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE IF NOT EXISTS `userinfo` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `mobile_number` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `userinfo`:
--

--
-- Dumping data for table `userinfo`
--

INSERT DELAYED IGNORE INTO `userinfo` (`user_id`, `username`, `password`, `firstName`, `lastName`, `mobile_number`, `amount`) VALUES
(1, 'pongsan', '1234', 'Pongsan', 'Kanthon', '0811111111', 115900),
(2, 'Thitima', '1234', 'Thitima', 'Kotawat', '0822222222', 190000);
